import sys
import ast
import zss

def main():
    if len(sys.argv) == 4 and sys.argv[1] == "cmp":
        return do_cmp(sys.argv[2], sys.argv[3])
    elif len(sys.argv) == 4 and sys.argv[1] == "dst":
        return do_dst(sys.argv[2], sys.argv[3])
    elif len(sys.argv) == 3 and sys.argv[1] == "run":
        return do_run(sys.argv[2])
    else:
        print("Usage: python treeops.py <cmd> <file 1> <optional file 2>")
        return -1

# Provide the solution to Exercise 2 by implementing the function below
def do_cmp(fname1, fname2):
    # read file 1 into variable
    # read file 2 into variable
    # get AST for file 1
    # get AST for file 2
    # compare the AST 

    return -1

# Provide the solution to Exercise 3 by implementing the function below
def do_dst(fname1, fname2):
    # get AST for file 1
    # get AST for file 2
    # compare the distances between the AST's
    # return distance
    return -1

# Provide the solution to Exercise 4 by implementing the function below
def do_run(fname):
    # read line by line all the lines in the python file
    # generate AST to keep track of file
    # evaluate 
    # return final answer
    return -1


if __name__ == "__main__":
    main()